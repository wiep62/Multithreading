package com.example.springexample.controllers;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.TreeMap;

// поменяли в 17 пункте @Controller
@RestController

public class DefaultController {

    private TreeMap<Integer, String> todo;

    public DefaultController() {
        todo = new TreeMap<>();
        todo.put(1, "one");
        todo.put(2, "jcdjdsdd");
        todo.put(3, "jcdjdsdd");
        todo.put(4, "jcdjdsdd");
    }


    // убрали на 17 пункте  @ResponseBody
    // @RequestMapping(path = "/hello/{name}")
//переделали на  на 17 пункте    @RequestMapping(path = "/hello/", method = RequestMethod.POST)
    @GetMapping(path = "/todo")
    public TreeMap<Integer, String> get() {
        return todo;
    }

    @PostMapping(path = "/todo")
    public ResponseEntity post(@RequestParam String item) {
        if (item == null || item.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); //код 400
        }
//todo если сайт не пустой мы его добавим в список туду:
    todo.put(todo.lastKey() + 1,  item);
        return new ResponseEntity(HttpStatus.CREATED);  //веренм ResponseEntity со статусом OK (HttpStatus) или КРЕЙТЕД (HttpStatus.CREATED), т.к. мы добавили новый пункт
    }


    @PutMapping(path = "/todo/{id}")
    public ResponseEntity put(@PathVariable int id, @RequestParam String item) {
        todo.put(id, item);
        return new ResponseEntity(HttpStatus.OK); //код 200
    }

    @DeleteMapping(path = "/todo/{id}")
    public ResponseEntity put(@PathVariable int id) {
        todo.remove(id);
        return new ResponseEntity(HttpStatus.OK); //код 200
    }








    //СТАРОЕ:
  /*  public String hello(@RequestParam String name) {
        return "Hello SPRING" + name;
    }*/
 /*   public String hello() {
        return "Hello SPRING";
    }*/
  /*  public String hello(@RequestParam String name) {
        return "Hello SPRING" + name;
    }
*/
    // public String hello(@PathVariable String name) {
   /* public String hello(@RequestParam String name) {
        return "Hello SPRING" + name;
    }*/
}

