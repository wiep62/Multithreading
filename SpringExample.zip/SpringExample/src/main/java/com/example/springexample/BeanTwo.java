package com.example.springexample;

import org.springframework.stereotype.Component;

@Component
public class BeanTwo {
    //доб-ем метод:
    public void sayBeanTwo() {
        System.out.println("Я - BeanTwo");
    }
}
