package com.example.springexample.services;

import com.example.springexample.dto.CommentDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.TreeMap;

@Service
public class CommentCRUDService implements CRUDService<CommentDto> {

    @Value("${comment.length.max}") //
    private Integer lengthMax; //переменная в которую попадает файл конфигурации

    private final TreeMap<Integer, CommentDto> storage = new TreeMap<>();

    @Override
    public CommentDto getById(Integer id) {
        System.out.println("Getting comment by id: " + id);
        return storage.get(id);
    }
//получение всего списка:
    @Override
    public Collection<CommentDto> getAll() {
        System.out.println("Getting all comments");
        return storage.values();
    }
//создание элемента: нужно добавить элемент с определенным идентификатором и установить этому элементу соотв-ий идентификатор
  //берем текущийий максимальный ключ и прибавим к нему 1.
    //у нашего коментария установим идентификатор и добавим его с СТОРЕДЖ
    @Override
    public void create(CommentDto item) {
        System.out.println("Creating comment: " + item);
        int nextId = (storage.isEmpty() ? 0 : storage.lastKey()) + 1;
        item.setId(nextId); //есть коментарий, можем обрезать по длине или выбрасывать исключения
        if (item.getText().length() > lengthMax) {
            throw new RuntimeException("Comment is too long");
        }
        storage.put(nextId, item);
    }
//обновление:
    //для того чтобы обновить элемент под указанным id мы можем положить его в storage , но лочше у item установить в явном виде этот идентификатор (неизвестно какой может придти параметр)
    @Override
    public void update(Integer id, CommentDto item) {
        System.out.println("Updating comment: " + id);
//положим его в сторедж под этим идентификатором (если он тут есть), если его там нет то можно ничего не делать:
     //сделаем проверку, если сторедж не содержит ключ, то мы ничего не делаем
if (!storage.containsKey(id)) {
    return;
}
        if (item.getText().length() > lengthMax) {
            throw new RuntimeException("Comment is too long");
        }
        item.setId(id);
        storage.put(id, item);
    }
//удаление:
    @Override
    public void delete(Integer id) {
        System.out.println("Deleting comment: " + id);
storage.remove(id);
    }
}
