Inversion of Control (инверсия управления) — это принцип
   управления жизненным циклом объектов приложения,
   которое переходит от приложения к фреймворку
Dependency Injection (внедрение зависимостей) —
   это механизм, при котором сам фреймворк передаёт
   объектам их зависимости вместо того, чтобы создавать
   эти зависимости самостоятельно в коде и добавлять их

1. есть папка с ресурсами, тестами , и основными классами, ПОМ файл (добавляем в него зависимости для СПРИНГ )
2. pom.xml:
<parent>
   <groupId>org.springframework.boot</groupId>
   шаблон для созд-ия приложений на ДЖАВА с исп. спрринг бут, помогает уст-ить правильные версии библиотек и настроить проект чтобы он работал правильно
   все остальные версии будут уст-ся в зависимости с   <version>3.1.3</version>
   <artifactId>spring-boot-starter-parent</artifactId>
   <version>3.1.3</version>
   </parent>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
делает процесс созд. веб прилож. проще (вкл. в себя всё необходимое для создания ВЕБ приложений)
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
предост-яет инстр-ты для написания запуска тестов:
        <artifactId>spring-boot-starter-test</artifactId>
    </dependency>
</dependencies>

    _<build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
ПОЗВОЛЯЕТ УПАКОВАТЬ ПРИЛОЖЕНИЕ В ДЖАР-ФАЙЛ:
                <artifactId>spring-boot-maven-plugin</artifactId>
                <version>3.1.3</version>
            </plugin>
        </plugins>
    </build>

    <properties>
        <maven.compiler.source>17</maven.compiler.source>
        <maven.compiler.target>17</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
3. Переименуем МАИН в SpringExampleApplication и Добавляем аннотацию @SpringBootApplication
4. Нужно изменить метод МАИН и добавить         SpringApplication.run(SpringExampleApplication.class, args);
   args - аргументы приложения
   SpringExampleApplication.class - указания на класс в котором происх. запуск
5. Запускаем приложение, обр-ем внимание на последние 2 строчки:
   2024-12-01T11:13:45.794+03:00  INFO 7092 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
   2024-12-01T11:13:45.804+03:00  INFO 7092 --- [           main] c.e.s.SpringExampleApplication           : Started SpringExampleApplication in 1.821 seconds (process running for 2.721)
- приложение запустилось на сервере Tomcat на порту 8080  и сделала это за 1.821 seconds
- по сути приложение готово к работе
6. открываем браузер и вводим localhost:8080
Всю основную работу сделал СПРИНГ БУТ.
  ПОД капотом у @SpringBootApplication
@Target({ElementType. TYPE})
@Retention(RetentionPolicy. RUNTIME)
@Documented
@Inherited
@SpringBootConfiguration - обесп авт. настр. прилож. СПРИНГБУТ и определяет класс как основной. класс помеченный этой аннотацией будет исп-ся как точка входа в приложение
@EnableAutoConfiguration - позв-ет СБ автом-ки сканировать и конфигурировать бины (специальные классы) и комп-ты в приложении, на основе настроек классов, доступных в  класс ПЭФ. она Основ-ся на наличии зависимости, 
которые обычно доб-ся в приложение при использовании СБ-стартер зависимостей.
-ComponentScan - указывает спринг контекст ( указывает спринг контейнеру где искать компоненты или БИНы). Она указыв. на нач-ую точку для сканирования и автоматической регистрации БИНОВ в СПРИНГ КОНТЕЙНЕРЕ.
При сканирование СПРИНГ найдет все классы, компоненты, начиная с этого класса и НИЖЕ ПО ИЕРАРХИИ и зарегестрирует их как бины в контейнере, доступные для использования в приложении.
Так же можно отфильровать необх-ые для приложения бины и компоненты.
@ComponentScan(excludeFilters = {@org.springframework. context. annotation. ComponentScan. Filter(type = org. springframework. context. annotation. FilterType. CUSTOM, classes = {org. springframework. boot. context. TypeExcludeFilter.class}),@org.springframework. context. annotation. ComponentScan. Filter(type = org. springframework. context. annotation. FilterType. CUSTOM, classes = {org. springframework. boot. autoconfigure. AutoConfigurationExcludeFilter.class})})
public @interface SpringBootApplication
extends java. lang. annotation. Annotation
7. СПРИНГ КОНТЕНЬЕР - по сути КИВЕЛЬЮ хранилище (хранятся все необходимые для работы бины).
СБ - сам находит бины, создает и хранит их у себя и выполняет некоторые из них для запуска приложения.
8. НАЙДЕМ КОНТЕЙНЕР И ПОСМОТРИМ СКОЛЬКО БИНОВ ОН СОЗДАЕТ:
в методе майн создаем класс АПЛИКЕЙШЕН КОНТЕКСТ. объект этого класса будет возвр-ть метод run. создадим массив(кот-ый будет содержит имена бинов):
и выведем эти имена.
ApplicationContext context = SpringApplication.run(SpringExampleApplication.class, args);
   String[] beanNames = context.getBeanDefinitionNames();
   System.out.println("Количество бинов: " + beanNames.length);
   for (String beanName : beanNames) {
   System.out.println(beanName);
   }
ВЫВОД:
   Количество бинов: 143
   org.springframework.context.annotation.internalConfigurationAnnotationProcessor
   org.springframework.context.annotation.internalAutowiredAnnotationProcessor
и другие названия бинов
9. СОЗДАЕМ СВОИ БИНЫ (BeanOne (добавим констр-р и метод), BeanTwo(только метод)):
 В каждый класс добавим аннотацию @Component - она подскажет СПРИНГ-ФРЕЙМВОРКУ, что нужно создать объект нашего класса (каждого из этих классов) - БИН
И положить в СПРИНГ-контейнер
10. Изменим МАЙН, попробуем найти наши бины и вызовем у них соотв-ие методы
    BeanOne beanOne = context.getBean("beanOne", BeanOne.class);
    BeanTwo beanTwo = context.getBean("beanTwo", BeanTwo.class);
        beanOne.sayBeanOne();
        beanTwo.sayBeanTwo();
Было 143 стало 145 бинов, они из контекста легко достаются 
Т.О. создание классов и пометкой их анн-ией КОМПОНЕНТ позволило СФ создать их автоматически и положить их в контекст.

ИНВЕРСИЯ УПРАВЛЕНИЯ, бины спринг были обн-ны и автом. проиниц-ны.
наш 1ый бын, должен иниц-ся только после созд-ия 2-го бина в конструкторе.
В данном случае акт-ся мех-зм внедрения зависимостей:
-когда спринг обнар-ет 1ый бин, он определяет , что для его создия треб. 2-ой бин, Т.О. спринг инициализирует 2-ой бин а затем завершает иниц-ию 1-го бина, 
передавая первый БИН в констр-р второго .
ВСЁ ЭТО ПРОИСХОДИТ В РАМКАХ КОНТЕЙНЕРА СПРИНГ-контекст
12. Бин - основной строительный блок в спринг приложении.
Контейнер созд. настр-ет и управляет жизненным циклом бина.
Бин может быть любым классом, кот-ый несет опред-ое значение или функц-ть в приложении.
    (это м.б. объект предост-ий польз-ля, продукт, соединение с БД).
Процесс созд-ия управл-ия и при необходимости уд-ия бинов ПРИНГ КОНТЕЙНЕРОМ назыв0ся жизненным циклом бина

Bean и его жизненный цикл
**Способы поиска Bean
• Аннотации. Вы можете использовать аннотации, такие
как @Component, @Service, @Repository и другие

из пакета org.springframework.stereotype, чтобы пометить
классы как компоненты. Spring сканирует пакеты вашего
приложения на наличие классов с этими аннотациями
и регистрирует их как бины
• Явное указание бинов. Вы можете явно указать бины
в конфигурационных классах с помощью аннотации
@Bean. Это позволяет создавать бины на основе
определённых методов
• XML-конфигурация. В случае использования XMLконфигурации вы можете определить бины в файлах
конфигурации, указывая классы вручную
Жизненный цикл бина:
Bean и его жизненный цикл
• Инициализация (Initialization) созд. экзэмпляра бина, использую конструктор класса
• Внедрение зависимостей - если бин зависит от других бинов, спринг внедряет эти зависимости автоматически
• Выполнение методов инициализации - если у бина есть методы, аннотированные как пост-констракт или настроены для вызова после инициализации - они будут выполнены
• Использование (Using) - бин активно используется внутри приложения 
• Уничтожение (Destruction) - если у бина есть методы, аннотированые как придестрой или настроеные для вызова перед уничтожением - они будут выполнены
• Освобождение ресурсов - бин освобождает ресурсы которые он использовал, такие как соединение с БД или другие системные ресурсы
• Удаление из контекста - бин удаляется из контекста приложения и перестает быть доступным

ЗНАЧИМОСТЬ БИНОВ В ТОМ ЧТО ОНИ ПОЗВОЛЯЮТ ВЫП. ДОП-ЫЕ ДЕЙСТВИЯ НА РАЗЛИЧНЫХ ЭТАПАХ.
Мы моджем использовать МЕТОДЫ ИНИЦИАЛИЗАЦИИ для выполнения начальной настройки, подключение к БД и других операций
Методы уничтожения - помогают корректно завершить работу бина и освоб. занятый ресурс

в классе БИНОНЕ добавим 2 метода (постконстракт и предистрой):
в логе  произошел Вызов метода postConstruct он вызыолся до старта приложения
postConstruct идет после  лога инициализации СПРИНГ КОНТЕКСТ:
2024-12-03T18:28:56.510+03:00  INFO 8732 --- [           main] o.apache.catalina.core.StandardEngine    : Starting Servlet engine: [Apache Tomcat/10.1.12]
2024-12-03T18:28:56.586+03:00  INFO 8732 --- [           main] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring embedded WebApplicationContext
2024-12-03T18:28:56.586+03:00  INFO 8732 --- [           main] w.s.c.ServletWebServerApplicationContext : Root WebApplicationContext: initialization completed in 830 ms
Вызов метода postConstruct
2024-12-03T18:28:56.904+03:00  INFO 8732 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2024-12-03T18:28:56.913+03:00  INFO 8732 --- [           main] c.e.s.SpringExampleApplication           : Started SpringExampleApplication in 1.589 seconds (process running for 2.276)
Количество бинов: 145
При остановке приложения в логах появляется метод preDestroy, т.к. при остановке приложения спринг начинает очищать контекст (удаляет бины),
перед удалением БИНА бинВан вызвал этот метод .
так происходит не всегда, поведение зависит от области видимости.

Область видимости Bean
Bean и его жизненный цикл: 
Singleton (Одиночка). Бины с областью видимости
singleton создаются только один раз в контексте приложения
и существуют на протяжении всего его жизненного цикла.
Они широко используются для создания общих ресурсов,
кешей и других объектов, которые можно безопасно
разделять между различными компонентами приложения.
Prototype (Прототип). Бины с областью видимости
prototype создаются каждый раз при запросе. Это означает,
что каждый новый запрос к бину будет возвращать новый
экземпляр объекта. Прототип-бины полезны в случаях,
когда требуется изолировать состояние между разными
запросами или когда объекты имеют короткоживущий
характер и должны создаваться заново для каждого запроса.

**** Session (Сессия). Бины с областью видимости session
создаются один раз для каждой сессии пользователя
в веб-приложении. Они позволяют хранить данные,
специфичные для сеанса пользователя, и обеспечивают
изоляцию между разными пользователями.
*** Request (Запрос). Бины с областью видимости request
создаются для каждого HTTP-запроса в веб-приложении.
Это позволяет хранить данные, специфичные для текущего
запроса, и гарантирует изоляцию между разными запросами. 
* по умолчанию спринг создает наши БИНЫ в области видимости синглТОН.
* а для бинов с обл. видимости ПРОТОТИП метод предестрой не будет вызван при уничтожении бина, т.к. в данном случае спринг не управляет его жизненным циклом после выдачи экземпляра бина.

ЭТО НЕОБХ. ЗНАТЬ ДЛЯ ПРАВИЛЬНОГО ВЫБОРА И НАСТРОЙКИ БИНОВ, В ЗАВИСИМОСТИ ОТ ПОТРЕБНОСТЕЙ ПРИЛОЖЕНИЯ. ОПТИМИЗАЦИИ ИСПОЛЬЗОВАНИЯ 
РЕСУРСОВ И ОБЕСПЕЧЕНИЯ ПРАВИЛЬНОГО ФУНКЦИОНИРОВАНИЯ.

13. Контроллеры. Аннотации @Controller    и @RestController
    Концепция MVC (НА ЭТОЙ КОНЦЕПЦИИ СОЗД-СЯ БОЛЬШИНСТВО ФРЕЙМВОРКОВ НА БЭКЕНДЕ)
    • Model. Работа с базой данных
    • View. Отображение данных пользователям (ФОРМИРОВАНИЕ ВЕБ-СТРАНИЦ)
    • Controller. Обработка запросов и формирование ответов
   
    Клиент (браузер) Веб-приложение на сервере
                         Controller (БРУЗЕР ДЕЛАЕТ ЗАПРОС К БЕКЕНД ПРИЛОЖЕНИЮ, В ЭТОТ МЕТОД ПОПАДАЮТ ТЕ ПАРАМЕТРЫ, КОТОРЫЕ БЫЛИ ПЕРЕДАНЫ В ЗАПРОСЕ)
   ДАЛЕЕ Controller ОБРАЩ-Ся К КОМПОНЕНТУ Model И ЗАПРАШИВАЕТ ИЗ БД НУЖНУЮ ИНФОРМАЦИЮ .
ПОСЛЕ ТОГО КАК ИНФА С БД ЗАПРОШЕНА , ОНА М.Б. ПРЕОБРАЗОВАНА В Т.Ч. В ШАБЛОН (КОД HTML) КОТОРЫЙ НУЖНО БУДЕТ ОТДАТЬ БРАУЗЕРУ, ЧТОББЫ ОН ЕГО ОТОБРАЗИЛ
                            Model
    Controller ОБРАЩ-Ся К КОМПОНЕНТУ View И ФОРМИРУЕТ СВОЙ ОТВЕТ И ЭТОТ ОТВЕТ ОН ВОЗВР-ЕТ КЛИЕНТУ 
View

    Controller — эта аннотация делает класс
    «контроллером» — классом, методы которого
    отвечают за обработку HTTP-запросов
    и формирование ответов.
    14. ДЛЯ ТОГО ЧТОБЫ СОЗДАТЬ КОНТРОЛЛЕР НЕОБХ-МО СОЗДАТЬ СООТВ-ИЙ ПАКЕТ controllers и создадим в нем класс DefaultController
    снабдим его анн. @Controller - эта аннот. явл0ся псевдонимом для аннотации компонент
    созд.     public String hello()  сделаем так чтобы он возвр-л ее по определенному адрессу , который мы откроем в браузере
        @RequestMapping(path = "/hello")
        public String hello() {
        return "Hello SPRING";
        }
    ПО УМОЛЧАНИЮ ТО ЧТО МЫ НАПИСАЛИ В     return "Hello SPRING"; БУДЕТ ПЫТАТЬСЯ ПОДКЛЮЧАТЬ ШАБЛОН ВЕБ-СТРАНИЦЫ. НЕ НАЙДЕМ ЕГО И МЫ ПО ПРЕЖНЕМУ ВИДЕТЬ СТРАНИЦУ ОШИБКИ
    КОТОРОЕ ВИДЕЛИ, КОГДА ЗАПУСКАЛИ ПРИЛОЖЕНИЕ БЕЗ КОНТРОЛЛЕРА
    *ДЛЯ ТОГО ЧТОБЫ НА СТРАНИЦЕ ОТОБРАЖАЛСЯ ТЕКСТ     return "Hello SPRING"; НУЖНО ДОБАВИТЬ АННОТАЦИЮ      @ResponseBody
        @ResponseBody - должен возвр-ть данные в теле http - ответа, а не возвр. имя шаблона.
    это полезно если х=отим вернуть данные в формате, который может может быть прямо передан клиенту (JSON, xml и т.д. ).
    Так же можем расширять запросы, передавая разные значения через параметры и используя переменную пути, предавать объекты в теле запроса.
    -передаем значение в код через http://localhost:8080/hello?name="ssss"
    -для этого нам нужно его получить в коде:
        public String hello(@RequestParam String name) {
        return "Hello SPRING " + name;
        }
    МЫ МОЖЕМ ПЕРЕДАВАТЬ ПАРАМЕТРЫ МЕТОДОВ КОНТРОЛЛЕРОВ!
    МОЖЕМ ПЕРЕДАТЬ КОЛИЧЕСТВО НОВОСТЕЙ, КОТОРОЕ НАМ НУЖНО ВЫВЕСТИ, И В ДАЛЬНЕЙШЕМ ДЕЛАТЬ ЗАПРОС К БД С УЧЕТОМ ЭТОГО КОЛИЧЕСТВА

        ДЛЯ ТОГО ЧТОБЫ ВСЕ ВЫГЛЯДЕЛО КРАСИВО, МОЖНО УКАЗАТЬ ШАБЛОН:
    15.     @RequestMapping(path = "/hello/{name}")
    public String hello(@PathVariable String name) {
    return "Hello SPRING" + name;
    }
до нижнего пункта всё это было запросы методом ГЕТ.
16. ЗАПРОСЫ МЕТОДОМ POST:

@Controller
public class DefaultController {

    @ResponseBody
@RequestMapping(path = "/hello/", method = RequestMethod.POST)


public String hello(@RequestParam String name) {
return "Hello SPRING" + name;
}
POST запрос сделать можно толко спец-ым инстр-ом Postman
отправив ПОСТ запрос http://localhost:8080/hello/ получаем ответ:
{
"timestamp": "2024-12-03T18:11:04.699+00:00",
"status": 400,
"error": "Bad Request",
"path": "/hello/"
}
это ошибка, т.к. мы пытаемся прочитать параметр name  :
public String hello(@RequestParam String name) {
return "Hello SPRING" + name;
}
 А в постмане мы этот парметр не передаем, нужно его добавить в поле КЕЙ body (from-data)

17. РЕАЛИЗУЕМ ПОЛНОЦЕННОЕ ПРИЛОЖЕНИЕ КОТОРОЕ МОЖЕТ УПРАВЛЯТЬ СУЩНОСТЬЮ: (приложение управлением списка дел):
- в defaultController добавим :
    private TreeMap<Integer, String> todo; Тримэп в котором есть ключи и идентификаторы дел, названия дел (ТУДУ)
    public DefaultController() { контроллер в котором инициализируем туду лист
    todo = new TreeMap<>();
    }
- РЕАЛИЗУЕМ 4 МЕТОДА: (Добавление, редактирование, получение всего списка удаления ) лучше это делать с АННОТАЦИЕЙ РЕСТКОНТРОЛЛЕР
она делает так что все возвр-ые данные, кот-ые будут возвр-ся из наших методов  будут в формате JSON; убираем аннотацию РЕСПОНСБАДИ
  RequestMapping переделываем на гет маппинг и пост маппинг
- GetMapping будет обр-ся к адресу ТУДУ, этот метод будет возвр-ть список дел, параметров у этого метода *(hello) не будет, метод возвращает TODO
  @GetMapping(path = "/todo/")
  public TreeMap<Integer, String> get() {
  return todo;
  }
- для того чтобы протестировать наш метод, заполним в ручную ТУДУ лист делами в public class DefaultController {
через .put
18. Сделаем в постмане гет запрос, который будет называться ТУДУ без каких либо параметров (можем его переименовать из New Request  в Get list)
19. Добавим метод, который будет добавлять ДЕЛО в список (он может ничего не возвр. или может (успешный ответ))
    ResponseEntity - для того чтобы могли установить код этого ответа, этот метод мы будем вызывать путем запроса метода ПОСТ по тому же адресу, мы будем в него передавать новое дело (ТЕКСТ)
    @PostMapping(path = "/todo")
    public ResponseEntity post(@RequestParam String item) {
    if (item == null || item.isEmpty()) {
    return new ResponseEntity<>(HttpStatus.BAD_REQUEST); //код 400
    }
    //todo если сайт не пустой мы его добавим в список туду:
    todo.put(todo.lastKey() + 1,  item);
    return new ResponseEntity(HttpStatus.CREATED);  //веренм ResponseEntity со статусом OK (HttpStatus) или КРЕЙТЕД (HttpStatus.CREATED), т.к. мы добавили новый пункт
    }
20. Создадим дело в постмане и получим его:
-Добавляем реквест (ПОСТРЕКВЕСТ) по такому же адресу и в Body(form-data) будем отпр. само дело:
- Key = item, Value = название дела
21. реализуем редактирование списка:
    @PutMapping(path = "/todo/{id}")
    public ResponseEntity put(@PathVariable int id, @RequestParam String item) {
    todo.put(id, item);
    return new ResponseEntity(HttpStatus.OK); //код 200
    }
22. Делитмапинг д.б. с такимиже параметрами но параметр СТРИНГ сдесь не нужен
    @DeleteMapping(path = "/todo/{id}")
    public ResponseEntity put(@PathVariable int id) {
    todo.remove(id);
    return new ResponseEntity(HttpStatus.OK); //код 200
    }
    23. Добавляем в постмане новые запросы на удаление и редактирование
    - для удаление нужно указывать номер элемента в конце зпароса http://localhost:8080/todo/3
    - для редактирования нужно указывать номер элемента в конце зпароса http://localhost:8080/todo/3  и в Body(form-data) будем отпр. само дело:
- Key = item, Value = название дела
24. Сервисы. Аннотация @Service (псевдоним аннот. КОМПОНЕНТ)
    - Аннотация   @Service   Используется для обозначения классов, которые
    содержат бизнес-логику и операции, необходимые для работы приложения. (м.б. класс, который обраб-ет данные, взаимод-ует с внешними приложениями по HTTP (обраб-ет текст и удаляет из него все ссылки) )
25. создадиим класс который будет работать с коментариями пользователей (будет возвр их список, создавать, редакт и удалять).
    создадим отдельный контроллер (CommentController).
26. создадим интерфейс кот. будет содержать методы работы с комментариями (CRUD методы). Создадим папку СЁРВИСЕС и создадим в ней интерфейс CRUDService, мы его типизируем и добавим методы
метод уд-ия может возврть наш объект, а может не возвр-ть ничего
27. Создадим объект коментария, в котром будет работать наш сервис
- Создадим папку dto (объекты передачи данных) - эт плосские объекты, в которых будут ГЕТТЕРЫ, СЕТТЕРЫ и ПОЛЯ
- Создадим класс CommentDto: пусть у коментария будут след-ие свойства:
  import lombok.AllArgsConstructor;
  import lombok.Getter;
  import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class CommentDto {
private Integer id;
private String text;
private String author;
}
28. Подключим к этому проекту ЛАМБОК для того чтобы не создавать конструкторы, геттеры и сеттеры
    <dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    </dependency>
29. Создадим реализацию нашего  интерфейса в классе CommentCRUDService наследуем его от интерфейса CRUDService типизированным классом CommentDto
- реализуем все методы и создадим ТРИМЭП в котором будут лежать наши коментарии:
-     private final TreeMap<Integer, CommentDto> storage = new TreeMap<>();
у нас получился готовый сервис для работы с коментариями 
-
30. Создадим соотв-ий контроллер, CommentController мы создали - сделаем так чтобы все его методы отвечали по одному и томуже адресу
- поэтому добавим над классом в CommentController РЕКВЕСТМАППИНГ в качестве парметра укажем адрес по которому будут осущ-ся запросы 
- создадим переменную в которой будет хранится  CommentCRUDService :  private final CommentCRUDService commentCRUDService;
- сделаем конструктор коммент контроллер который будет принимать в качестве параметра commentService и устонавливать его этой переменной:
  public CommentController(CommentCRUDService commentService) {
  this.commentService = commentService;
  }
- пропишем операции которые задавали в CommentCRUDService (методы получ-ся простые по 1-ой строчке)
- Вся логика должна быть вынесена в сервисе 
- 
МЕХАНИЗМ ДОБАВЛЕНИЯ БИНОВ В ВПРИНГ ЕЩЕ НАЗЫВАЕТСЯ @Autowire
ВМЕСТО КОНСТРУКТОРА:
public CommentController(CommentCRUDService commentService) {
this.commentService = commentService;
}
 МОЖНО ИСПОЛЬЗОВАТЬ АННОТАЦИЮ Autowired

    - @Autowired — это аннотация в Spring Framework, используемая для автоматической инъекции
      (внедрения) зависимостей. Она позволяет Spring автоматически находить подходящий бин (компонент)
      и внедрять его в поле, метод или конструктор класса без необходимости явно создавать экземпляр зависимости.
     
 
    ******  Способы внедрения      зависимостей (DI)
           Через конструктор: это наиболее рекомендуемый и явный
    способ. Spring автоматически передаст подходящий бин
    в этот конструктор при создании экземпляра класса. Явно
    аннотацию можно не указывать
public CommentController(CommentCRUDService commentService) {
this.commentService = commentService;
}
*****
          Через поля: вы можете аннотировать поля класса
    аннотацией @Autowired. Spring автоматически внедрит
    подходящий бин в эти поля при создании экземпляра
    класса. Этот подход менее явный, и некоторые считают
    его менее предпочтительным для чистоты кода

          Через методы-сеттеры: вы можете аннотировать методысеттеры класса аннотацией @Autowired. Spring внедрит
    зависимость в соответствующий метод после создания
    экземпляра класса. Также этот способ менее явный
    и может быть менее чистым с точки зрения архитектуры

 31. ДЛЯ ТОГО ЧТОБЫ НАМ РАБОТАТЬ В ПОСТМАНЕ С ПРОЕКТОМ, НУЖНО В ПОСТМАЕН СОЗДАТЬ СООТВ-ИЕ API:
     http://localhost:8080/comment
в create item http://localhost:8080/comment будем созд. комментарий и отправлять его в теле сообщения (Body -> row (JSON формат) указваем соотв-ие свойства нашего коментария
ИХ ВСЕГО ДВА:
    ТЕКСТ и АВТОР (в комент ДТО указано)
     {
     "text": "1 comentaryi",
     "author": "pipka filipka"
     }
- удалим коментарий № 3
- 3 раза вызовем создание коментария(он 3 раза будет один и тот же)
- редактирповать будем второй (в формате JSON)

при запуске программы возникла ошибка:

Action:
Consider defining a bean of type 'com.example.springexample.services.CommentCRUDService' in your configuration.
Process finished with exit code 1
нужно определить БИН CommentCRUDService в нашей конфигурации. Это значит , что его нужно пометить как СЕРВИС

ПРИ ЗАПУСКЕ ПРОГРАММЫ ПОЯВЛЯЕТСЯ ОШИБКА О ТОМ ЧТО У НАС не определился последный ключ в коллекции ТРИМЕП (потому что его нет):
at java.base/java.util.TreeMap.lastKey(TreeMap.java:298) ~[na:na]
ДЕЛАЕМ ДЛЯ ЭТОГО СЛУЧАЯ ЗАЩИТУ:
int nextId = storage.isEmpty() ? 0 : storage.lastKey() + 1;
в методе public void create(CommentDto item) {

СЕРВИСЫ ЛУЧШЕ СОЗДАВАТЬ В ВИДЕ ИНТЕРФЕЙСОВ, А ПОТОМ ИМПЛЕМЕНТИРОВАТЬ  ИХ В КОНКРЕТНЫЕ КЛАССЫ!! 
-

32. Конфигурация   Spring-приложений

Файл конфигурации (src/main/resources) он содержит пары ключ-значения для настройки разных параметров приложения. значения  заданные в этом файле, влияют на поведение приложения при его запуске.
этот файл может быть в 1-ом из 2-ух форматов:
application.properties (свойства и значения пишутся через "=" ,  вложеные свойства разделяются точкой), это класический формат ДЖАВА приложений
server.port=8085 и

application.yml более соврем-ый формат конфигурации (разделение ключей и значений происходит через : , а вложеные свойства указываются на отдельных строках с отступами слева)
server:
port: 8085
Примечание: формат называется YAML

33. создадим файл application.yml в папке src/main/resources
изменим порт на котром запускается ДЖАВА приложение (по умолчанию 8080)
    server:
    port: 8085
поменяем уровень логирования проекта:
    с уровня ИНФО на уровень ДЕБАГ/ будет уровень логирования ДЕБАГ для корневого уровня нашего проекта.
    logging:
    level:
    root: debug
теперь выводятся сообщения не только относящиеся к проекту, но и к самому спрингу.
мы можем указать какие логи нам нужны, поменяем на наш пакет:
    server:
    port: 8085
    logging:
    level:
    com.example.springexample: debug

ЕСТЬ ДОКУМЕНТАЦИЯ ДЛЯ НАСТРОЙКИ КОНФИГУРАЦИИ СПРИНГА
- 
ДОБАВЛЯЕМ СВОЙ ПАРАМЕТР: (максимальная длинна комментариев 300 символов)
comment:
length:
max: 300 (теперь этот параметр нужно как то учесть в сервисе комментов).
Для этого нужно использовать аннотацию Value:
@Value("${comment.lenght.max}")
private Integer lengthMax;
Аннотация @Value позволяет внедрять значения
из application.properties непосредственно в ваш код.
Вы можете использовать её над полями, методами
или даже параметрами методов.
 ---добавим проверку в методы создания и изменения комментариев в классе CommentCRUDService
if (item.getText().length() > lengthMax) {
throw new RuntimeException("Comment is too long");
}
если оставить коммент больше 300 символ то программа выдаст:
2024-12-07T18:18:28.310+03:00 ERROR 1036 --- [nio-8085-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed: java.lang.RuntimeException: Comment is too long] with root cause

java.lang.RuntimeException: Comment is too long
at com.example.springexample.services.CommentCRUDService.create(CommentCRUDService.java:39) ~[classes/:na]
at com.example.springexample.controllers.CommentController.createComment(CommentController.java:36) ~[classes/:na]
at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method) ~[na:na]
at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77) ~[na:na]
at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43) ~[na:na]
at java.base/java.lang.reflect.Method.invoke(Method.java:569) ~[na:na]
at org.springframework.web.method.support.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:205) ~[spring-web-6.0.11.jar:6.0.11]
at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:150) ~[spring-web-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:118) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:884) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:797) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:87) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:1081) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:974) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:1011) ~[spring-webmvc-6.0.11.jar:6.0.11]
at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:914) ~[spring-webmvc-6.0.11.jar:6.0.11]
at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:590) ~[tomcat-embed-core-10.1.12.jar:6.0]
at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885) ~[spring-webmvc-6.0.11.jar:6.0.11]
at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:658) ~[tomcat-embed-core-10.1.12.jar:6.0]
at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:205) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:149) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:51) ~[tomcat-embed-websocket-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:174) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:149) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:100) ~[spring-web-6.0.11.jar:6.0.11]
at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116) ~[spring-web-6.0.11.jar:6.0.11]
at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:174) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:149) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.springframework.web.filter.FormContentFilter.doFilterInternal(FormContentFilter.java:93) ~[spring-web-6.0.11.jar:6.0.11]
at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116) ~[spring-web-6.0.11.jar:6.0.11]
at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:174) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:149) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:201) ~[spring-web-6.0.11.jar:6.0.11]
at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:116) ~[spring-web-6.0.11.jar:6.0.11]
at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:174) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:149) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:166) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:90) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:482) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:115) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:93) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:74) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:341) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:391) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:63) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.coyote.AbstractProtocol$ConnectionHandler.process(AbstractProtocol.java:894) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.util.net.NioEndpoint$SocketProcessor.doRun(NioEndpoint.java:1740) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:52) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.util.threads.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1191) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.util.threads.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:659) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:61) ~[tomcat-embed-core-10.1.12.jar:10.1.12]
at java.base/java.lang.Thread.run(Thread.java:840) ~[na:na]


а постман:

{
"timestamp": "2024-12-07T15:18:28.325+00:00",
"status": 500,
"error": "Internal Server Error",
"path": "/comment"
}


НАСТРОЙКА КОНФИГ-ЫХ ФАЙЛОВ СЧИТАЕТСЯ ХОРОШЕЙ ПРАКТИКОЙ , ВЫНОСИТЬ ВСЕ ДАННЫЕ КОТОРЫЕ МОГУТ МЕНЯТЬСЯ В ЭТИ ФАЙЛЫ БЫВАЕТ ОЧЕНЬ ПОЛЕЗНО. МЫ МОЖЕМ ВЫНЕСТИ НЕ ТОЛЬКО 1 ЗНАЧЕНИЕ , НО И ЦЕЛЫЕ СПИСКИ
-
---ConfigurationProperties---

Аннотация @ConfigurationProperties позволяет
связать значения из файлов application.properties
с полями класса в вашем приложении. 
 СОЗДАДИМ В КОНФ-ОМ ФАЙЛЕ , НОВЫЕ ПАРАМЕТРЫ И НОВЫЙ КЛАСС С ПОЛЯМИ, ОДНОИМЕННЫМИ С ЭТИМИ ПАРАМЕТРАМИ
ДОБАВИМ РАЗДЕЛ APP:
app:
name: MyApp
maxConnections: 10
enableFeature: true
На уровне контроллеров создадим еще 1 ПЭКЕДЖ, назовем его КОНФИГ и добавим в него класс AppConfig
- добавим туда геттеры и сеттеры.
- аннотацию Component чтобы СПРИНГ создал БИН
- добавим аннотацию @ConfigurationProperties(prefix = "app") который будет соотв-ть префиксу новых переменных новых переменных в ФАЙЛЕ НАСТРОЙКИ ЯМЛ
- переопр. метод ту стринг, с помощью которого сможем вывести значения всех этих полей
- добавим метод, который будет выводить в консоль, конф-ию из объекта этого класса:

@PostConstruct - чтобы этот метод срабатывал после создания бина
public void printConfig(){
  System.out.println(this); в консоль будем выводить текущий объект, приведенный к строке (то что toString выводит)
  }
Данные из файла конфигурации успешно прочитаны и выведены в консоль методом ПРИНТКОНФИГ:
НАШ БИН успешно ЗАПОЛНИЛСЯ ПОЛЯМИ ИЗ ФАЙЛА КОНФИГУРАЦИИ и мы могли бы им пользоваться в процессе работы нашего приложения
AppConfig{name='null', maxConnections=0, enableFeature=false}
2024-12-07T18:47:30.018+03:00  INFO 3804 --- [           main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8085 (http) with context path ''
2024-12-07T18:47:30.028+03:00  INFO 3804 --- [           main] c.e.s.SpringExampleApplication           : Started SpringExampleApplication in 1.414 seconds (process running for 1.902)_

 
когда прилож. загр-ся, спринг автоматически ищет и загружает конфигур-ые файлы и ищет он их в нескольких местах.
Места поиска файлов конфигурации:
1. В той же папке, что и JAR-файл:
application.yml
application.jar
2. В папке config рядом с JAR-файлом:
config/application.yml
application.jar
3. В classpath приложения (в папке resources)
4. В папке config в classpath приложения
(resources/config) 

Явное указание пути к файлу конфигурации
Конфигурация Spring-приложений
java -jar myapp.jar --
spring.config.location=/path/to/config/

Профили Spring
Вы можете создавать дополнительные
конфигурационные файлы для специфичных
профилей вашего приложения, например:
application-dev.yml — для разработки.
application-test.yml — для тестирования.

ПРОФИЛИ ПОМОГАЮТ ОПРЕДЕЛЯТЬ КАКИЕ БИНЫ, НАСТРОЙКИ И КОМПОНЕНТЫ Д.Б. АКТИВНЫМИ В ЗАВИСИМОСТИ ОТ ОКРУЖЕНИЯ, В КОТОРОМ РАБОТАЕТ НАШЕ ПРИЛОЖЕНИЕ  
-
ОПРЕДЕЛ-СЯ ПРОФИЛИ В КОНФИГ-ОМ ФАЙЛЕ
АКТИВНЫЙ ПРОФИЛЬ МОЖНО УСТАНОВИТЬ В:
    spring:
        profiles:
            active: dev

application-dev.properties — для разработки.
application-test.properties — для тестирования.
Активация профиля dev:
spring.profiles.active=dev

КЛЮЧЕВЫЕ КОНЦЕПЦИИ СПРИНГ:
инвершенл КОНТРОЛ И ДЕПЕНДЕСИ инжекШЕН, которые лежат в основе фреймворка и позволяют создать модульные и легко расширяемые приложения
